//
//  PhotoCollectionViewCell.swift
//  mpoo_collection_01
//
//  Created by Germán Santos Jaimes on 14/11/22.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell{
                                            
    @IBOutlet weak var photo: UIImageView!
    
    
}
