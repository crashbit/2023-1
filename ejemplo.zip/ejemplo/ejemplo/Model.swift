//
//  Model.swift
//  ejemplo
//
//  Created by Germán Santos Jaimes on 12/09/22.
//

import Foundation

struct Alumno{
    var titulo:String
    var subtitulo: String
}
