//
//  ViewController.swift
//  cm_instagram_01
//
//  Created by Germán Santos Jaimes on 16/11/22.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource {
    
    var colors: [UIColor] = [UIColor.red, UIColor.green, UIColor.blue, UIColor.brown, UIColor.cyan]
    
    var images: [String] = ["1", "2", "3", "4", "5"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return colors.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "celda", for: indexPath) as! ImageCollectionViewCell
        
        cell.backgroundColor = colors[indexPath.item]
        cell.imagen.image = UIImage(named: images[indexPath.item])
        
        return cell
        
    }

}

