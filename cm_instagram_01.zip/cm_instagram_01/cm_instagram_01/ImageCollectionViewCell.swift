//
//  ImageCollectionViewCell.swift
//  cm_instagram_01
//
//  Created by Germán Santos Jaimes on 16/11/22.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imagen: UIImageView!
}
