//
//  ViewController.swift
//  mpoo_values_01
//
//  Created by Germán Santos Jaimes on 14/09/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var letrero: UILabel!
    @IBOutlet weak var cajita: UITextField!
    var valor = "0"
    var recepcion = "0"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func boton(_ sender: UIButton){
         valor = cajita.text ?? "0"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let second = segue.destination as! SecondViewController
        second.recepcion = valor
        second.primerViewController = self
    }
    
    func modificaLetrero(cadena:String){
        letrero.text = cadena
    }
    
    

}

