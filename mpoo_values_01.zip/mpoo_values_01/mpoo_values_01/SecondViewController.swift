//
//  SecondViewController.swift
//  mpoo_values_01
//
//  Created by Germán Santos Jaimes on 14/09/22.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var letrero: UILabel!
    @IBOutlet weak var cajita: UITextField!
    var recepcion = ""
    var valor = ""
    var primerViewController: ViewController!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        letrero.text = recepcion
    }

    @IBAction func boton(_ sender: UIButton){
        valor = cajita.text ?? "0"
        primerViewController.modificaLetrero(cadena: valor)
        navigationController?.popViewController(animated: true)
    }
    
    
}
