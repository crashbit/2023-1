//
//  ViewController.swift
//  pokemon_generico
//
//  Created by Germán Santos Jaimes on 05/11/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {

    var pokemones: [PokemonApi] = []
    @IBOutlet weak var tablita: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }

    func getData(){
        let url = URL(string: "https://pokeapi.co/api/v2/pokemon")
        
        let task = URLSession.shared.dataTask(with: url!) { data,response, error in
            if let data = data {
                let json = JSONDecoder()
                
                let resultados = try? json.decode(Resultados.self, from: data)
                print(resultados)
                if resultados != nil{
                    for objeto in resultados!.results{
                        let nombre = objeto.name
                        let url = objeto.url
                        print("for")
                        let pokemon  = PokemonApi(name: nombre, url: url)
                        
                        self.pokemones.append(pokemon)
                    }
                    DispatchQueue.main.async{
                        self.tablita.reloadData()
                    }
                }
                
            }
        }
        task.resume()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(pokemones.count)
        return pokemones.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        let renglon = pokemones[indexPath.row]
        let nombre = renglon.name
        print(nombre)
        cell.textLabel?.text = nombre
        return cell
        
        
    }
}

