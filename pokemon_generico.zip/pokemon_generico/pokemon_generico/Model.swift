//
//  Model.swift
//  pokemon_generico
//
//  Created by Germán Santos Jaimes on 05/11/22.
//

import Foundation

struct Resultados: Codable{
    var results:[PokemonApi]
}

struct PokemonApi: Codable{
    var name: String
    var url : String
}
